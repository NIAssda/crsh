const nameGirl = 'Em';
const giftUrl = 'https://hentaiz.in/aoharu-snatch-1/';
const eventName = 'Chúc Mừng 08-03';
const titleCard = 'Tặng người ấy';
const contentCard = 'Chúc honey của anh 08/03 tràn ngập niềm vui và những nụ cười. Mong điều đẹp nhất sẽ đến với em trong hôm nay và cả những ngày sau';


const giftImage = '111.png';
const base64 = '';
const giftImageBase64 = "data:image/png;base64, " + base64;
